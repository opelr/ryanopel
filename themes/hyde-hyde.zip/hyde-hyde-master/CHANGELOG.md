# Changelog

## Version 1.0

- Fork from [Hyde](https://github.com/spf13/hyde) 
- Adapt to [Nate Finch's blog](https://npf.io)'s colors and fonts.
- Refactor `basedof.html` and corresponding pages `index.html`, `single.html`, `list.html`
    - define blocks `content` and `footer` that will be fulfilled by each different type of layout.
